
package com.ibm.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.bean.Project;
import com.ibm.project.dao.Project_Dao;

@Service
public class Project_Service {

	@Autowired
	Project_Dao pdao;
	public List<Project> getProject(){
		return pdao.getProject();
	}
	public Optional<Project> getProject(Integer projectId) {
		return pdao.getProject(projectId);
	}

	public void addProject(String projectName, String projectStartDate, String projectEndDate, String projectDescription, String projectDevApproach, String projectStatus) {
		pdao.addProject(projectName,projectStartDate,projectEndDate, projectDescription, projectDevApproach,  projectStatus);
	}
	
	public void updateProject(Project project, Integer id) {
		pdao.updateProject(project, id);
		
	}

	public void deleteProject(Integer id) {
		pdao.deleteProject(id);
	}


	
}
