package com.ibm.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.dao.Task_Dao;

@Service
public class Task_Service {

	@Autowired
	Task_Dao tdao;
}
