package com.ibm.project.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.project.bean.Project;

@Repository
public interface Project_Repository  extends CrudRepository<Project,Integer>{

	List<Project> findByProjectName(String name);
	
}
