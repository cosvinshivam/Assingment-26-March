package com.ibm.project.dao;

import org.springframework.stereotype.Repository;

@Repository
public class Task_Dao {

}
