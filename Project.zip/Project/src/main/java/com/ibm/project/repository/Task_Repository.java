package com.ibm.project.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ibm.project.bean.Task;


public interface Task_Repository extends CrudRepository<Task,Integer>{

	List<Task> findByProjectProjectId(int id); 
}
