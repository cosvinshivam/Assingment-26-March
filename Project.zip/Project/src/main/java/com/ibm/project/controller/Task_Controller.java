package com.ibm.project.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.bean.Project;
import com.ibm.project.bean.Task;
import com.ibm.project.service.Task_Service;


@RestController
public class Task_Controller {
	
	@Autowired
	Task_Service service;

	@RequestMapping("/project/{id}/task") // Get all places that belong to a user
	List<Task> getProject(@PathVariable int id){
		return service.getAllProject(id);
	}
	
	
	//For getting single place by id
	@RequestMapping("/project/{id}/task/{id}") //Change the url here
	Optional<Task> getTask(@PathVariable("id") int id) {
		return service.getTask(id);
	}
	
	
	//For adding a place by : post, add User variable in PlaceP and getters and setters for it
	@RequestMapping(method = RequestMethod.POST, value = "/project/{id}/task/")
	void addTask(@RequestBody Task task, @PathVariable int id) {
		task.setProject(new Project("", "", "","", "", "", id));
		service.addTask(task);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/project/{id}/task/{id}")
	void updateTask(@RequestBody Task task, @PathVariable String userId, @PathVariable int id) {
		
		task.setProject(new Project("", "", "","","","",id));
		service.updateTask(task);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{id}/task/{id}")
	void deletePlace(@PathVariable int id) {
		service.deleteTask(id);
	}
	

}
