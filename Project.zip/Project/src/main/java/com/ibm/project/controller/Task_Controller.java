package com.ibm.project.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.service.Task_Service;

@RestController
public class Task_Controller {
	
	@Autowired
	Task_Service service;

}
