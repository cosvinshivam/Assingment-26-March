package com.ibm.project.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Task	{
	@Id
	int taskId;
	String taskName, taskMemberName, taskDescription;
	int taskDuration;
	
	@ManyToOne
	Project project; //Tie this place to a particular User instance, Foriegn key to a primary key in the UserP table
	
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	public Task() {
		
	}
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskMemberName() {
		return taskMemberName;
	}
	public void setTaskMemberName(String taskMemberName) {
		this.taskMemberName = taskMemberName;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public int getTaskDuration() {
		return taskDuration;
	}
	public void setTaskDuration(int taskDuration) {
		this.taskDuration = taskDuration;
	}
	public Task(int taskId, String taskName, String taskMemberName, String taskDescription, int taskDuration,
			Project project) {
		super();
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskMemberName = taskMemberName;
		this.taskDescription = taskDescription;
		this.taskDuration = taskDuration;
		this.project = project;
	}
	
     
}
