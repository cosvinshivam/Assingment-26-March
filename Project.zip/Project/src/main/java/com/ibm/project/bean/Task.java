package com.ibm.project.bean;

import javax.persistence.Entity;

@Entity
public class Task {

}
