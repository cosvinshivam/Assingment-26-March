package com.ibm.spring.SpringJdbc;


public class AppTest 
{
	
}