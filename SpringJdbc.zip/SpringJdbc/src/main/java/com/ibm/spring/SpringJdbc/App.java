package com.ibm.spring.SpringJdbc;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
		  ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
//		  NamedParamDemo dao=(NamedParamDemo)context.getBean(NamedParamDemo.class);
//		  dao.update("J420","ABC");
//		  System.out.println("Name after update is "+dao.getUserName("ABC","PPPP"));
//		  //dao.delete("ABC");
//		  System.out.println("Name after update is "+dao.getUserName("ABC","PPPP"));
        JdbcDao dao=(JdbcDao) context.getBean(JdbcDao.class);
        User use=new User("SHIVAM","HELLO");
        System.out.println(dao.getUserCount());
        //System.out.println(dao.getUserName("J420"));
        System.out.print("USER NAMES:");
        //System.out.println(dao.getDetails().getUserName());
        
        dao.addNewUser(use);
        for(User user: dao.getDetails()) {
        	System.out.println(user.getUserName());
        }
        System.out.println("UPDATE------------");
        dao.updateUser(use);
        for(User user: dao.getDetails()) {
        	System.out.println(user.getUserName());
        }
        System.out.println("DELETE------------");
        dao.deleteUser("ABC");
        for(User user: dao.getDetails()) {
        	System.out.println(user.getUserName());
        }
    }
}
