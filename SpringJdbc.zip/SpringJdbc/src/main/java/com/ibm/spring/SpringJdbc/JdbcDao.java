package com.ibm.spring.SpringJdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
@Repository
public class JdbcDao {
	@Autowired
	UserMapper abc;
	
	//#4
	@Autowired
	DataSource ds;
	//#5
	JdbcTemplate jdbcTemplate;
	public DataSource getDs() {
		return ds;
	}
    @Autowired
	public void setDs(DataSource ds) {
		this.jdbcTemplate=new JdbcTemplate(ds);	
	}
	//#6
 public	int getUserCount(){
		String sql="select count(uname) from user_login";
		//initialize the jdbcTemplate
		//jdbcTemplate=new JdbcTemplate();
		//set the data source
        //jdbcTemplate.setDataSource(this.ds);
		//execute Query
		return jdbcTemplate.queryForObject(sql,Integer.class);
	}
 
 String getUserName(String userId)
 {
	 String sql="select uname from user_login where uname=?";
	 return jdbcTemplate.queryForObject(sql,new Object[] {userId},String.class);	 
 }
 
 void addNewUser(User user)
 {
	System.out.println(user);
	String sql="insert into user_login values(?,?)";
	jdbcTemplate.update(sql,new Object[]{user.getUserName(),user.getPassword()}); 
 }
 void updateUser(User user)
 {
	String sql="update user_login set uname='ABC' where uname=?" ;
	jdbcTemplate.update(sql,new Object[]{user.getUserName()}); 
 }
 void deleteUser(String u)
 {
	String sql="delete from user_login where uname=?";
	jdbcTemplate.update(sql,new Object[]{u});
 }
 
 List<User> getDetails()
 {
	 String sql="select * from user_login ";
	 return jdbcTemplate.query(sql,abc);
	 
 } 
}

class UserMapper implements RowMapper<User>{
      @Autowired
		User user;
		//=new User("SHIVAM","HELLO");
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		System.out.println("user: " + user);
		user.setUserName(rs.getString("uname"));
		user.setPassword(rs.getString(2));
		return user;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		System.out.println("Inside setter for User");
		this.user = user;
	}
	
}



