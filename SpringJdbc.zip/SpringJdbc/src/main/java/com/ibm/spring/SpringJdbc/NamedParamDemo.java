package com.ibm.spring.SpringJdbc;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;
@Component
public class NamedParamDemo {

	DataSource ds;
	
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public DataSource getDs() {
		return ds;
	}

	@Autowired
	public void setDs(DataSource ds) {
		this.namedParameterJdbcTemplate=new NamedParameterJdbcTemplate(ds);
	}
	
	
	String getUserName(String u,String pass) {
		String sql="select uname from user_login where uname=:un and password=:pp";
	    SqlParameterSource paramSource=new MapSqlParameterSource("un",u)
	    		                            .addValue("pp",pass);
	    return namedParameterJdbcTemplate.queryForObject(sql, paramSource, String.class);  
	}
	
	void update(String old,String n)
	{
		String sql="update user_login set uname=:n where uname=:old";
	    SqlParameterSource paramSource=new MapSqlParameterSource("old",old)
	    		                            .addValue("n",n);
	    namedParameterJdbcTemplate.update(sql, paramSource);	
	}
	
	void delete(String  n)
	{
		String sql="delete from user_login where uname=:old";
	    SqlParameterSource paramSource=new MapSqlParameterSource("old",n);		                           
	    namedParameterJdbcTemplate.update(sql, paramSource);	
	}
	
}
