
package com.mail.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class MailController {

	@Autowired
    private JavaMailSender javaMailSender;
	
	@RequestMapping("/mail/{id}")
	void sendEmail(@PathVariable("id") String id) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(id);
        msg.setSubject("Reset Password");
        msg.setText("https://www.google.com");
        javaMailSender.send(msg);
    }
}
