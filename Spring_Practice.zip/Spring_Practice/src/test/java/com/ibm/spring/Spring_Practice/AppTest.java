package com.ibm.spring.Spring_Practice;


import org.springframework.context.support.ClassPathXmlApplicationContext;



public class AppTest 
{
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		School school =context.getBean("school",School.class);
		
		Engineer test=(Engineer) context.getBean(ElectronicEngineer.class);
		test.work();
		//school.show();
	}
	
}