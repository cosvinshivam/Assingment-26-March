package com.ibm.spring.Spring_Practice;
import javax.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ElectronicEngineer implements Engineer {
//    @Autowired
//    @Qualifier("student1")
	
	@Resource(name="student1")

	Student student;
	
    public ElectronicEngineer(Student student) {
    	this.student=student;
		
	}
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public void work() {
		System.out.println("EE NAME:"+this.getStudent().getName());
		
	}
   @PostConstruct
	public void setThingsUp()
	{
		System.out.println("its working");
	}
   
   @PreDestroy
   void shutDown()
   {
	   System.out.println("HELLO");
   }

}

//JSR 250 Specifications












