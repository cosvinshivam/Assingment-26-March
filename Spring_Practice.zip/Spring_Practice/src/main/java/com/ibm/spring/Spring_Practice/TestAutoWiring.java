package com.ibm.spring.Spring_Practice;

public class TestAutoWiring implements Engineer {

	Student student2;


	public Student getStudent2() {
		return student2;
	}


	public void setStudent2(Student student2) {
		this.student2 = student2;
	}


	public void show() {
		System.out.println("-----"+this.getStudent2().getName());
	}


	public void work() {
		
		
	}
	
	
}
