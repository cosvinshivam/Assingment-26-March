package com.ibm.spring.Spring_Practice;

@FunctionalInterface
public interface Engineer {
	void work();

}



