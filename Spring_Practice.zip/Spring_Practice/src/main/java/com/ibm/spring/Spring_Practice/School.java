package com.ibm.spring.Spring_Practice;

import java.util.List;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
public class School {

//public class School implements InitializingBean,DisposableBean {
	
	public School() {
		System.out.println("ITS RUNNING");
	}
	
	String address;
	List<Student> student;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Student> getStudent() {
		return student;
	}
	public void setStudent(List<Student> student) {
		this.student = student;
	}
	void startProcessing()
	{
		System.out.println("START PROCESSING........");
	}
	void destroy()
	{
		System.out.println("DESTROYED...");
	}
	
	void show()
	{
		for(Student student:student)
		System.out.println("ID:"+student.getId()+" NAME:"+student.getName()+" Address:"+this.getAddress());
	}
//	public void destroy() throws Exception {
//		System.out.println("SCHOOL BEAN ABOUT TO BE DESTROYED :-)");
//	}
//	public void afterPropertiesSet() throws Exception {
//		System.out.println("SCHOOL BEAN IS LOADING........");
//	}
	
	
}
