package com.ibm.project.employee.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.employee.bean.Employee;
import com.ibm.project.employee.services.Employee_Services;

@RestController
public class Employee_Controller {

	@Autowired
	Employee_Services service;
	
	@RequestMapping("/project/emp") 
	List<Employee> getEmployee() {
		return service.getEmployee();
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/emp")
	void updateEmployee(@RequestBody Employee emp) {
		service.updateEmployee(emp);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{id}/emp")
	void deleteEmployee(@PathVariable int id) {
			service.deleteEmployee(id);
	}
}
