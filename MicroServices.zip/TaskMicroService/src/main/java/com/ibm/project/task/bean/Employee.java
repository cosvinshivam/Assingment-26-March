package com.ibm.project.task.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    int empId;
	String empName;
	int empWorkHrs;
	String empRole;
	public Employee() {
		
	}
	
	public Employee(int empId, String empName, int empWorkHrs,String empRole) {
		this.empId = empId;
		this.empName = empName;
		this.empWorkHrs = empWorkHrs;
		this.empRole=empRole;
	}

	public String getEmpRole() {
		return empRole;
	}

	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpWorkHrs() {
		return empWorkHrs;
	}
	public void setEmpWorkHrs(int empWorkHrs) {
		this.empWorkHrs = empWorkHrs;
	}
	
}
