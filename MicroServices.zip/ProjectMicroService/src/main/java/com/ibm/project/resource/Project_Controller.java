package com.ibm.project.resource;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.bean.Project;
import com.ibm.project.services.Project_Services;
@RestController
public class Project_Controller {

	@Autowired
	Project_Services service;
	@RequestMapping("/project")
	List<Project> getProject() {
		return service.getProject();
	}

	@RequestMapping("/project/{id}")
	Optional<Project> getProject(@PathVariable Integer id) {
		return service.getProject(id);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/add")
	void addProject(@RequestBody Project project) {
		service.addProject(project.getProjectName(), project.getProjectStartDate(), project.getProjectEndDate(),
				project.getProjectDescription(), project.getProjectDevApproach(), project.getProjectStatus(),
				project.getProjectId());
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/{id}")
	void updateProject(@RequestBody Project project, @PathVariable Integer id) {
		service.updateProject(project, id);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{id}")
	void deleteProject(@PathVariable Integer id) {
		service.deleteProject(id);
	}
}
