package com.ibm.project.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ibm.project.bean.Employee;
import com.ibm.project.bean.Project;
import com.ibm.project.bean.Task;

@RestController
public class ProjectLauncher_Controller {

	@Autowired
	RestTemplate restTemplate;
	
//  *************************Admin CRUD API'S************************//

	@RequestMapping("/admin")
	String getAdmin() {
		String anotherServiceUrl = "http://admin-service/admin";
		String result = restTemplate.getForObject(anotherServiceUrl, String.class);
		return result;
	}

 //**** *************************Employee CRUD API'S************************//

	@RequestMapping("/project/emp")
	Object getEmployee() {
		String getEmployeeServiceUrl = "http://employee-service/project/emp";
		Object[] result = (Object[]) restTemplate.getForObject(getEmployeeServiceUrl, Object[].class);
		return Arrays.asList(result);
	}

	@RequestMapping("/project/{id}/empCount")
	int getProjectEmployee(@PathVariable("id") int id) {
		String getEmployeeCountServiceUrl = "http://employee-service/project/" + id + "/empCount";
		int result = restTemplate.getForObject(getEmployeeCountServiceUrl, Integer.class);
		return result;
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/emp")
	void updateEmployee(@RequestBody Employee emp) {
		String updateServiceUrl = "http://employee-service/project/emp";
		restTemplate.put(updateServiceUrl, emp);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{id}/emp")
	void deleteEmployee(@PathVariable int id) {
		String deleteServiceUrl = "http://employee-service/project/" + id + "/emp";
		restTemplate.delete(deleteServiceUrl);
	}
	

 //*************************Project CRUD API'S************************//
	
	@RequestMapping("/project")
	Object getProject() {
		String getProjectServiceUrl = "http://projectMicro-service/project";
		Object[] result = (Object[]) restTemplate.getForObject(getProjectServiceUrl, Object[].class);
		return Arrays.asList(result);
	}

	@RequestMapping("/project/{id}")
	Object getProjecByID(@PathVariable int id) {
		String getProjectByIDServiceUrl = "http://projectMicro-service/project/"+id;
		Object[] result = (Object[]) restTemplate.getForObject(getProjectByIDServiceUrl, Object[].class);
		return Arrays.asList(result);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/add")
	void addProject(@RequestBody Project project)
	{	String addProjectServiceUrl = "http://projectMicro-service/add";
	    restTemplate.postForObject(addProjectServiceUrl,project,Project.class);	
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/{id}")
	void updateProject(@RequestBody Employee emp,@PathVariable int id) {
		String updateServiceUrl = "http://projectMicro-service/project/"+id;
		restTemplate.put(updateServiceUrl, emp);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{id}")
	void deleteProject(@PathVariable int id) {
		String deleteServiceUrl = "http://projectMicro-service/project/"+id;
		restTemplate.delete(deleteServiceUrl);
	}

 //   *************************Task CRUD API'S************************//
	@RequestMapping("/project/{id}/task")
	Object getTask(@PathVariable int id) {
		String getTaskServiceUrl = "http://task-service/project/"+id+"/task";
		Object[] result = (Object[]) restTemplate.getForObject(getTaskServiceUrl, Object[].class);
		return Arrays.asList(result);
	}
	
	@RequestMapping("/project/{pid}/task/{id}")
	Object getTaskByTaskId(@PathVariable int pid,@PathVariable int id) {
		String getTaskByIdServiceUrl = "http://task-service/project/"+pid+"/task/"+id;
		Object[] result = (Object[]) restTemplate.getForObject(getTaskByIdServiceUrl, Object[].class);
		return Arrays.asList(result);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/project/{pid}/{eid}/task/")
	void addTask(@RequestBody Task task, @PathVariable int pid, @PathVariable int eid) {
		String addTaskServiceUrl = "http://task-service/project/"+pid+"/"+eid+"/task/";
	    restTemplate.postForObject(addTaskServiceUrl,task,Task.class);	
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "/project/{pid}/{eid}/task/{tId}")
	void updateTask(@RequestBody Task task, @PathVariable int tId, @PathVariable int pid, @PathVariable int eid) {
		String updateServiceUrl = "http://task-service/project/"+pid+"/"+eid+"/task/"+tId;
		restTemplate.put(updateServiceUrl, task);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{pid}/task/{id}")
	void deleteTask(@PathVariable int id) {
		String deleteServiceUrl = "http://task-service/project/"+id+"/task/"+id;
		restTemplate.delete(deleteServiceUrl);	
	}
	
	
	
	
	
}
