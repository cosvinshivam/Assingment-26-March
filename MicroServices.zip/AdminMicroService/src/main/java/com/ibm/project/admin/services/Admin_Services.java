package com.ibm.project.admin.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.admin.bean.Admin;
import com.ibm.project.admin.dao.Admin_Dao;

@Service
public class Admin_Services {

	@Autowired
	Admin_Dao dao;
	
	public Iterable<Admin> getAdmin()
	{
		return dao.getAdmin();
	}
}
