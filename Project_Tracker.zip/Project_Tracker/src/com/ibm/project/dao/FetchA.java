package com.ibm.project.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class FetchA {
	
		static Connection con;
		
	static 	int n;
		static ResultSet rs;
		public static ResultSet fetchProjects() {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="select * from project_information";
				 Statement stmt=con.createStatement();
				 rs=stmt.executeQuery(sql);
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		
		public static ResultSet fetchUserDetails(String loggedId) {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String fetchQry = "select * from employee_signup where Emp_id = '"+loggedId+"'";
				Statement state = con.createStatement();
				rs = state.executeQuery(fetchQry);
			} catch (SQLException | ClassNotFoundException e) {
				System.out.println("Some error while fetching" + e);
			}
			return rs;
		}

		
		static 	public ResultSet details(String a)
		{
			System.out.println(a);
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="select * from project_information where Task_ID='"+a+"' ";
				 Statement stmt=con.createStatement();
				 //stmt.setInt(1, a);
				 rs=stmt.executeQuery(sql);
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		static 	public ResultSet image(String a)
		{
			System.out.println(a);
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="select * from employee_login where Emp_id='"+a+"' ";
				 Statement stmt=con.createStatement();
				 //stmt.setInt(1, a);
				 rs=stmt.executeQuery(sql);
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		static 	public int insert(String mid,String mname,String mtid,String mrole,String mhrs)
		{
			int i=0;
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="insert into user_workday values(?,?,?,?,?)";
				 PreparedStatement stmt=con.prepareStatement(sql);
				 stmt.setString(1,mid);
				 stmt.setString(2, mname);
				 stmt.setString(3, mtid);
				 stmt.setString(4, mrole);
				 stmt.setString(5, mhrs);
				 i=stmt.executeUpdate();
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			System.out.println(i);
	     return i;
		}
		static 	public ResultSet teamInfo(String a)
		{
			System.out.println(a);
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			     con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
				String sql="select * from user_workday where mtid='"+a+"' ";
				 Statement stmt=con.createStatement();
				 //stmt.setInt(1, a);
				 rs=stmt.executeQuery(sql);
				} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		
	}


