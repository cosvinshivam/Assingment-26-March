package com.ibm.project.task.resources;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.task.Repo.ProjectRepository;
import com.ibm.project.task.bean.Employee;
import com.ibm.project.task.bean.Project;
import com.ibm.project.task.bean.Task;
import com.ibm.project.task.services.Task_Services;

@RestController
public class Task_Controller {

	@Autowired
	Task_Services service;

	@Autowired 
	ProjectRepository prep;
	
	@GetMapping(value = "/download/project.xlsx")
    public ResponseEntity<InputStreamResource> excelProjectReport() throws IOException {
        List<Project> project =(List<Project>) prep.findAll();
		
		ByteArrayInputStream in = com.ibm.project.task.exceldownload.util.ExcelGenerator.projectsToExcel(project);

		HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=project.xlsx");
		
		 return ResponseEntity
	                .ok()
	                .headers(headers)
	                .body(new InputStreamResource(in));
    }

	@RequestMapping("/project/{id}/task")
	List<Task> getProject(@PathVariable int id) {
		return service.getAllProjectTask(id);
	}

	@RequestMapping("/project/{pid}/task/{tid}")
	Optional<Task> getTask(@PathVariable("tid") int id) {
		return service.getTask(id);
	}
	
	
	@RequestMapping("/tasks")
	List<Task> getAllTasks(){
		return (List<Task>) service.getAllTasks();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/project/{pid}/{eid}/task/")
	void addTask(@RequestBody Task task, @PathVariable int pid, @PathVariable int eid) {
		task.setProject(new Project(pid, "", "", "", "", "", ""));
		task.setEmp(new Employee(eid, "", 0, ""));
		service.addTask(task);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/{pid}/{eid}/task/{tId}")
	void updateTask(@RequestBody Task task, @PathVariable int tId, @PathVariable int pid, @PathVariable int eid) {

		task.setTaskId(tId);
		task.setProject(new Project(pid, "", "", "", "", "", ""));
		task.setEmp(new Employee(eid, "", 0, ""));
		service.updateTask(task);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{pid}/task/{id}")
	void deleteTask(@PathVariable int id) {
		service.deleteTask(id);
	}
	
	@RequestMapping(value="/project/{id}/count")
	int Count(@PathVariable int id)
	{
		return service.Count(id);
	}
}
