package com.ibm.project.task.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.task.bean.Task;
import com.ibm.project.task.dao.Task_Dao;
@Service
public class Task_Services {

	@Autowired
	Task_Dao tdao;

	public List<Task> getAllProjectTask(int id) {
		return tdao.getAllProjectTask(id);
	}

	public Optional<Task> getTask(int id) {
	
		return tdao.getTask(id);
	}

	public List<Task> getAllTasks(){
		return (List<Task>) tdao.getAllTasks();
	}
	
	public void deleteTask(int id) {
		tdao.deleteTask(id);		
	}

	public void updateTask(Task task) {
		tdao.updateTask(task);
	}
	
    public int Count(int id)
    {
    	return tdao.CountEmp(id);
    }
	public void addTask(Task task) {
		tdao.addTask(task);
	}

}
