package com.ibm.test.bean;

public class Training {
	private String tname;
    private	int tid,tseat;
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getTseat() {
		return tseat;
	}
	public void setTseat(int tseat) {
		this.tseat = tseat;
	}
	public Training(String tname, int tid, int tseat) {
		super();
		this.tname = tname;
		this.tid = tid;
		this.tseat = tseat;
	}
	public Training() {
		
	}
    
    

}
