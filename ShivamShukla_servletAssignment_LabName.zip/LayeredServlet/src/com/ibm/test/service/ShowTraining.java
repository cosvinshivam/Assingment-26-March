package com.ibm.test.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.test.bean.Training;
import com.ibm.training.dao.Fetch;

@WebServlet("/show")
public class ShowTraining extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      PrintWriter out=response.getWriter();
       ArrayList<Training> list= Fetch.fetch();
		for(Training t:list)
			{
			out.println("<table  align=center>");
			out.println(" <tr><td>Training Id</td><td>Training Name</td><td>Available Seats</td><td><a href=enroll?id="+t.getTid()+">Enroll</a></td></tr>");
			out.println("<tr><td>"+t.getTid()+"</td><td>"+t.getTname()+"</td><td>"+t.getTseat()+"</td><td></td></tr>");
			out.println("</table>");
			}

			
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
