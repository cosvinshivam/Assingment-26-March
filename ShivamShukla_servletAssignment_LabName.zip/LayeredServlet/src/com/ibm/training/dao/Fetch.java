package com.ibm.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.ibm.test.bean.Training;

public class Fetch {
static ArrayList<Training> list=new ArrayList<>();
public static	ArrayList<Training> fetch()
	{
	try {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm?useUnicode=true&u"
				+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
				"root","");
	
	Statement stmt = con.createStatement();
	String sql="select * from Training";
	ResultSet rs=stmt.executeQuery(sql);
	while(rs.next())
	{
		int id=rs.getInt(1);
		String name=rs.getString(2);
		int avs=rs.getInt(3);
		list.add(new Training(name,id,avs));
//		out.println("<table  align=center>");
//		out.println(" <tr><td>Training Id</td><td>Training Name</td><td>Available Seats</td><td><a href=enroll?id="+id+">Enroll</a></td></tr>");
//		out.println("<tr><td>"+id+"</td><td>"+name+"</td><td>"+avs+"</td><td></td></tr>");
//		out.println("</table>");
		
	}
	
	} 
	catch (ClassNotFoundException | SQLException e) {
         System.out.println(e);		
	}
	return list;
	}
	public static void update(int id)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm?useUnicode=true&u"
					+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root","");
		
		Statement stmt = con.createStatement();
		String sql1="update Training set AvailableSeats=AvailableSeats-1 where trainingId=?";
		PreparedStatement pst=con.prepareStatement(sql1);
		pst.setInt(1, id);
		pst.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	     
	}
}
