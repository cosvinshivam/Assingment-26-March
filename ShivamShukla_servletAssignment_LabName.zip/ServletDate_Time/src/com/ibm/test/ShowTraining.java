package com.ibm.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/show")
public class ShowTraining extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm?useUnicode=true&u"
					+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root","");
		
		Statement stmt = con.createStatement();
		String sql="select * from Training";
		ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			int id=rs.getInt(1);
			String name=rs.getString(2);
			int avs=rs.getInt(3);
			out.println("<table  align=center>");
			out.println(" <tr><td>Training Id</td><td>Training Name</td><td>Available Seats</td><td><a href=enroll?id="+id+">Enroll</a></td></tr>");
			out.println("<tr><td>"+id+"</td><td>"+name+"</td><td>"+avs+"</td><td></td></tr>");
			out.println("</table>");
			
		}
		
		} 
		catch (ClassNotFoundException | SQLException e) {
	         System.out.println(e);		
		}
			
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
