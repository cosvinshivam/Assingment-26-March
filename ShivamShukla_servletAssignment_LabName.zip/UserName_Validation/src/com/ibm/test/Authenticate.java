package com.ibm.test;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
	String name=request.getParameter("tf1");
	RequestDispatcher dispatcher=request.getRequestDispatcher("/success");
	RequestDispatcher dispatcher1=request.getRequestDispatcher("/index.html");
	
	if(name!=null)
	{
			if(name.equals("shivam"))
			{			
			dispatcher.forward(request, response);
		    }
			else
			{
		response.getWriter().println("Sorry USer Not exist");
		response.getWriter().println("<a href=signup.html>FOR SIGNUP</a>");
		dispatcher1.include(request, response);
			}	
	            }
	else
	{
		response.getWriter().println("Please Provide Valid Details............");
		dispatcher1.include(request, response);
	}
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
