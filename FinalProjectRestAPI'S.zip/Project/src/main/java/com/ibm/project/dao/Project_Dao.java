package com.ibm.project.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ibm.project.bean.Project;
import com.ibm.project.repository.Project_Repository;
@Repository
public class Project_Dao {

	    @Autowired
		Project_Repository repo;
		public List<Project> getProject(){
			return (List<Project>)repo.findAll();
		}

		
		public Optional<Project> getProject(Integer userId) {
			return repo.findById(userId);
		}

		public void addProject(String projectName, String projectStartDate, String projectEndDate, String projectDescription, String projectDevApproach, String projectStatus,int projectId) {
			Project project = new Project();
			project.setProjectName(projectName);
			project.setProjectStartDate(projectStartDate);
			project.setProjectEndDate(projectEndDate);
			project.setProjectDescription(projectDescription);
			project.setProjectDevApproach(projectDevApproach);
			project.setProjectStatus(projectStatus);
			project.setProjectId(projectId);
			repo.save(project);
		}
		
		public void updateProject(Project project, Integer id) {
			repo.save(project);
			
		}

		public void deleteProject(Integer id) {
			
			repo.deleteById(id);
			
		}

}
