package com.ibm.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.project.bean.Admin;

@Repository
public interface Admin_Repository extends CrudRepository<Admin, Integer>{

}
