package com.ibm.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.bean.Admin;
import com.ibm.project.dao.Admin_Dao;

@Service
public class Admin_Service {
	
	@Autowired
	Admin_Dao dao;
	
	public Iterable<Admin> getAdmin()
	{
		return dao.getAdmin();
	}

}
