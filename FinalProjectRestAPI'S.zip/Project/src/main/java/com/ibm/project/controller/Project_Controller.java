package com.ibm.project.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.bean.Project;
import com.ibm.project.service.Project_Service;

@RestController
public class Project_Controller {


	@Autowired
	Project_Service service;
	
	//Return all users
	@RequestMapping("/project")
	List<Project> getProject() {
		return service.getProject();
	}
	
	//Return a user
	@RequestMapping("/project/{id}")
	Optional<Project> getProject(@PathVariable Integer id) {
		return service.getProject(id);
	}
	
//	
//	//Add new user
//	
//	@RequestMapping(method = RequestMethod.POST, value = "/users")
//	void addUser(@RequestBody UserModal user) {
//		service.addUser(user);
//	}
//	@RequestMapping(method = RequestMethod.POST, value = "/add")
//	void addProject(@PathVariable String projectName,@PathVariable String projectStartDate,@PathVariable String projectEndDate,@PathVariable String projectDescription,@PathVariable String projectDevApproach, @PathVariable String projectStatus,@PathVariable int projectId) {
//		service.addProject(projectName,projectStartDate,projectEndDate, projectDescription, projectDevApproach,  projectStatus,projectId);
//	}

	@RequestMapping(method=RequestMethod.POST, value="/add")
	void addProject(@RequestBody Project project)	{
		service.addProject(project.getProjectName(), project.getProjectStartDate(), project.getProjectEndDate(), project.getProjectDescription(),
				project.getProjectDevApproach(), project.getProjectStatus(), project.getProjectId());
	}
	
	
	
//	
//	//update user details
//	
	@RequestMapping(method = RequestMethod.PUT, value ="/project/{id}")
	void updateProject(@RequestBody Project project,@PathVariable Integer id) {
		service.updateProject(project, id);
	}
	
	
	// Delete user
	
	@RequestMapping(method = RequestMethod.DELETE, value ="/project/{id}")
	void deleteProject(@PathVariable Integer id) {
		service.deleteProject(id);
	}
}
