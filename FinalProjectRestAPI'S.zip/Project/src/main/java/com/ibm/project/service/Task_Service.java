package com.ibm.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.bean.Task;
import com.ibm.project.dao.Task_Dao;

@Service
public class Task_Service {

	@Autowired
	Task_Dao tdao;

	public List<Task> getAllProject(int id) {
		return tdao.getAllProject(id);
	}

	public Optional<Task> getTask(int id) {
	
		return tdao.getTask(id);
	}

	public void deleteTask(int id) {
		tdao.deleteTask(id);		
	}

	public void updateTask(Task task) {
		tdao.updateTask(task);
	}
	

	public void addTask(Task task) {
		tdao.addTask(task);
	}


}
