package com.ibm.project.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Employee {

	@Id
    int empId;
	String empName;
	int empWorkHrs;
	@ManyToOne
	Project project;
	@OneToOne
	Task task;
	public Employee() {
		
	}
	
	public Employee(int empId, String empName, int empWorkHrs, Project project, Task task) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empWorkHrs = empWorkHrs;
		this.project = project;
		this.task = task;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpWorkHrs() {
		return empWorkHrs;
	}
	public void setEmpWorkHrs(int empWorkHrs) {
		this.empWorkHrs = empWorkHrs;
	}
	public Task getTask() {
		return task;
	}
	public void setTask(Task task) {
		this.task = task;
	}
	
}
