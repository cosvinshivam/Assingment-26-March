package com.ibm.project.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibm.project.bean.Employee;
import com.ibm.project.repository.Employee_Repository;

@Repository
public class Employee_Dao {

	@Autowired
	Employee_Repository repo;
	
	public int getProjectEmployee(int id)
	{
		return id;
		//return repo.getProjectEmployee(id);
	}
	
	public List<Employee> getEmployee(int id)
	{
		return repo.getAllByProjectId(id);
	}
	
	public void deleteEmployee(int id) {
		repo.deleteById(id);
	}

	public void updateEmployee(Employee emp) {
	     repo.save(emp);	
	}

	public void addEmployee(Employee emp) {
	    repo.save(emp);
	}
	
}
