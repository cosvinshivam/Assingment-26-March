package com.ibm.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.bean.Admin;
import com.ibm.project.service.Admin_Service;
@RestController
public class Admin_Controller {
	
	@Autowired
	Admin_Service service;
	
	@RequestMapping(name="/admin")
	Iterable<Admin> getAdmin() {
		return service.getAdmin();
	}

}
