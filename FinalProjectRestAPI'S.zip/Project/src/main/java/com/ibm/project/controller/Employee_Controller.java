package com.ibm.project.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.bean.Employee;
import com.ibm.project.bean.Project;
import com.ibm.project.bean.Task;
import com.ibm.project.service.Employee_Service;

@RestController
public class Employee_Controller {

	@Autowired
	Employee_Service service;

	// For getting single place by id
	@RequestMapping("/project/{id}/empCount") // Change the url here
	int getProjectEmployee(@PathVariable("id") int id) {
		return service.getProjectEmployee(id);
	}
	
	@RequestMapping("/project/{id}/emp") // Change the url here
	List<Employee> getEmployee(@PathVariable("id") int id) {
		return service.getEmployee(id);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/project/{pid}/task/{tid}/emp")
	void addEmployee(@RequestBody Employee emp, @PathVariable int pid,@PathVariable int tid) {

		emp.setProject(new Project(pid,"", "", "","", "", ""));
		emp.setTask(new Task(tid,"","","",100,emp.getProject()));
		service.addEmployee(emp);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/{pid}/task/{id}/emp")
	void updateEmployee(@RequestBody Employee emp, @PathVariable int id, @PathVariable int pid) {
     
		emp.setProject(new Project(pid,"", "", "","", "", ""));
		service.updateEmployee(emp);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{id}/task/{id}/emp")
	void deleteEmployee(@PathVariable int id) {
		service.deleteEmployee(id);
	}

}
