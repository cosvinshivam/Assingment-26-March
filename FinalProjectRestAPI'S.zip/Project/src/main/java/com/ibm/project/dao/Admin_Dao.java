package com.ibm.project.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibm.project.bean.Admin;
import com.ibm.project.repository.Admin_Repository;

@Repository
public class Admin_Dao {
	
	@Autowired
	Admin_Repository repo;

	public Iterable<Admin> getAdmin() {
		return repo.findAll();
	}

}
