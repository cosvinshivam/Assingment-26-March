package com.ibm.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.bean.Employee;
import com.ibm.project.dao.Employee_Dao;

@Service
public class Employee_Service {

	
	@Autowired
	Employee_Dao dao;
	public int getProjectEmployee(int id)
	{
		return dao.getProjectEmployee(id);
	}
	
	public List<Employee> getEmployee(int id)
	{
		return dao.getEmployee(id);
	}
	
	public void deleteEmployee(int id) {
		dao.deleteEmployee(id);
	}

	public void updateEmployee(Employee emp) {
	     dao.updateEmployee(emp);	
	}

	public void addEmployee(Employee emp) {
	    dao.addEmployee(emp);
	}
	
}
