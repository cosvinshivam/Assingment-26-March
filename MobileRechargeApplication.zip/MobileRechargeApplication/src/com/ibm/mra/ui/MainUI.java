package com.ibm.mra.ui;

import java.nio.channels.AcceptPendingException;
import java.util.Scanner;

import com.ibm.mra.beans.Account;
import com.ibm.mra.myexceptions.MyExceptions;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args)  {
		Scanner sc=new Scanner(System.in);
		Account a=new Account();
		AccountServiceImpl as=new AccountServiceImpl();
		String c="y";
		do {
		System.out.print("\n\t\t\tWELCOME\n\t\t\t");
		System.out.println("1) Account Balance Enquiry\n\t\t\t 2) Recharge Account\n\t\t\t 3) Exit\n\t\t\t ");
		int ch=sc.nextInt();
		sc.nextLine();
		if(ch==1)
		{
			System.out.print("Enter Mobile No :");
			try {
				a=as.getAccountDetails(sc.next());             //fetching user details
				System.out.println("Your Current Balance is Rs. "+a.getAccountBalance());   //print users balance
			} catch (MyExceptions e) {
				
				System.out.println(e);        //if any exception occurs then print userdefined exceptions
			}
	
			
					
		}
		else if(ch==2)
		{
			String mobileno="9999999999";
			 boolean isValid=true;
		    while(true){                             //repeat until the mobile number is validated
				System.out.print("Enter Mobile No :");
			    mobileno=sc.nextLine();
			    isValid= as.isValMob(mobileno);    ///validate whether a mobile number is of 10 digits
				if(isValid)
					break;
		    }
		    System.out.print("Enter Recharge Amount :");
		    double rechargeAmount=sc.nextDouble();
		    sc.nextLine();
           try {
			if(as.rechargeAccount(mobileno, rechargeAmount)==1) {		  //to recharge mobile balance
				System.out.println(" Your Account Recharged Successfully");
			}
			      
			    else
			    {
			    	throw new MyExceptions("ERROR:  Cannot Recharge Account as Given Mobile No  Does Not Exits  ");
			   
			    }
		} catch (MyExceptions e) {
			
			System.out.println(e);                                  //if any exception occurs then print userdefined exceptions
		}
		}
		else if(ch==3)
		{
			System.exit(0);
		}
		System.out.print("\n\t\t\tDo U Want To Use More (Y/N) :");
	      c=sc.next();
		}while(c.equalsIgnoreCase("Y"));      // to print menu again n again till user exits

}
}

