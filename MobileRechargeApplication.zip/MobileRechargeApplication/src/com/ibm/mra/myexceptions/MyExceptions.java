package com.ibm.mra.myexceptions;

public class MyExceptions extends Exception {

	public MyExceptions(String str) {
super(str);
	}
	
}
	

