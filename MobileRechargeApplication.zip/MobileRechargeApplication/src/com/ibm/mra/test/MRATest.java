package com.ibm.mra.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.ibm.mra.myexceptions.MyExceptions;
import com.ibm.mra.service.AccountServiceImpl;

public class MRATest {

AccountServiceImpl as;

public MRATest()
{
 as=new AccountServiceImpl();	
}
@Test
	void testKey()
	{
		assertEquals(true,as.validateid("999999977"));
	}
@Test
void rechargeTest() throws MyExceptions
{
	assertEquals(1, as.rechargeAccount("9999999999",1000));
}
	
}