package com.ibm.mra.service;

import com.ibm.mra.beans.Account;
import com.ibm.mra.myexceptions.MyExceptions;

public interface AccountService {
    
	Account getAccountDetails(String mobileNo) throws MyExceptions;    
    int rechargeAccount(String mobileno, double rechargeAmount) throws MyExceptions;
}
