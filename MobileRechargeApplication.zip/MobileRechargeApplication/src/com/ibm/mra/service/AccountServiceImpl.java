package com.ibm.mra.service;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDaoImpl;
import com.ibm.mra.myexceptions.MyExceptions;

public class AccountServiceImpl implements AccountService{
    public AccountDaoImpl ad=new AccountDaoImpl();
	
	@Override
	public Account getAccountDetails(String mobileNo) throws MyExceptions {
		if(ad.validateid(mobileNo))                   //to validate whether a mobile number exist or not
			return ad.getAccountDetails(mobileNo);
		else {	
			
				throw new MyExceptions("ERROR:  Cannot Recharge Account as Given Mobile No  Does Not Exits ");
			
		}
	}

	@Override
	public int rechargeAccount(String mobileno, double rechargeAmount) throws MyExceptions {
		
		if(ad.validateid(mobileno))          //to validate whether a mobile number exist or not
		{
		return ad.rechargeAccount(mobileno, rechargeAmount);
		}
		else {	
			
			throw new MyExceptions("ERROR:  Cannot Recharge Account as Given Mobile No  Does Not Exits ");
				
		}
	
		
	}
	
	public boolean validateid(String mobileNo){
		return ad.validateid(mobileNo);
	}

	public boolean isValMob(String mobileno) {
		int flag=0;
		if(mobileno.length()==10)
		{
		try {
			long l=Long.parseLong(mobileno);
			flag=1;
		   }
		catch (Exception e) {
			flag=0;
		}
		}
		else
			flag=0;
	if(flag==1)
		return true;
	else
	{
			try {
			throw new MyExceptions("Please Enter Valid Mobile Number and it must be of 10 digits");
			}
			catch(MyExceptions e)
			{
				System.out.println(e);
			}
		
	}
	return false;

}
}
