package com.ibm.mra.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.ibm.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	public Map<String,Account> accountEntry = new HashMap<>();  
	public AccountDaoImpl()
	{  
		
		accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200)); 
		accountEntry.put("9999999999", new Account("Prepaid", "Vaishali Bhasker", 1200)); 
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));  
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631)); 
		accountEntry.put("9010290131", new Account("Prepaid", "Anju", 521));  
	    accountEntry.put("9210210131", new Account("Prepaid", "Tushar", 632)); 
    }   

	@Override
	public Account getAccountDetails(String mobileNo) {
		return accountEntry.get(mobileNo);
		   	
	}	
		
		@Override
		public boolean validateid(String mobileNo){
	
			if(accountEntry.containsKey(mobileNo)) {
				return true;
			}

			else
				return false;
		}
	@Override
	  public int rechargeAccount(String mobileno, double rechargeAmount) {
		Set set = accountEntry.entrySet();
		Account a = accountEntry.get(mobileno);
		double tamt=a.getAccountBalance()+rechargeAmount;
      	a.setAccountBalance(tamt);
       a= accountEntry.put(mobileno,a);
       return 1;
	}

}
