package com.ibm.mra.dao;

import com.ibm.mra.beans.Account;

public interface AccountDao {
    Account getAccountDetails(String mobileNo);     
    int rechargeAccount(String mobileno, double rechargeAmount);
	boolean validateid(String mobileNo);
}
