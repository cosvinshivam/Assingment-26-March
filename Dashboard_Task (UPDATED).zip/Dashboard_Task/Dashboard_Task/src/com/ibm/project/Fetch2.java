package com.ibm.project;

public class Fetch2 {

}
