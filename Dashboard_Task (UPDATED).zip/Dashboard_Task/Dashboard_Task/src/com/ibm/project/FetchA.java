package com.ibm.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class FetchA {
	
		Connection con;
		Statement stmt;
		int n;
		ResultSet rs;
		public FetchA() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db?useUnicode=true&u"
							+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
							"root","");
			      stmt= con.createStatement();
			} catch (ClassNotFoundException | SQLException e) {
					e.printStackTrace();
			}

		}

		
		public ResultSet details(String a)
		{
			System.out.println(a);
			
			try {
				String sql="select * from search where name like '"+a+"%'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				//pstmt.setString(1, a);
				 rs=pstmt.executeQuery(sql);
				} catch (SQLException e) {
				e.printStackTrace();
			}
	     return rs;
		}
		
		
	}


