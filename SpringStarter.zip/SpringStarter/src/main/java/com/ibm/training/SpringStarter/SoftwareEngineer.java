package com.ibm.training.SpringStarter;

import java.util.List;

public class SoftwareEngineer {
	
	String name;
	int id;
	
	List<Address> addresses;

	

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public SoftwareEngineer(String name, int id) {
		this.name = name;
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	

	void work() {
		
		for(Address address: addresses) {
			System.out.println(address.getCity() + ", " + address.getPinCode());
		}
		
		
//		System.out.println("Hi there, I am " + this.getName() + ", with id: " + this.getId() + ", and I am ready to do software engineering. I would"
//				+ "be coding from " + address.getCity() + ", " + address.getPinCode());
	}
	
}
