package com.ibm.training.SpringStarter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	//The plain old way
//        SoftwareEngineer engineer = new SoftwareEngineer();
//        
//        engineer.work();
    	
    	// Load the spring config file
ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    	
    	//Load the bean
SoftwareEngineer engineer = context.getBean("softwareEngineer", SoftwareEngineer.class);

		//Call the method
engineer.work();
    	
    	
    	
    	
    	
    }
}
