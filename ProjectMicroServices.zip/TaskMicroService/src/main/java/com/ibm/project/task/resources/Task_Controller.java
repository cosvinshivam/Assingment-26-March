package com.ibm.project.task.resources;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.task.bean.Employee;
import com.ibm.project.task.bean.Project;
import com.ibm.project.task.bean.Task;
import com.ibm.project.task.services.Task_Services;

@RestController
public class Task_Controller {

	@Autowired
	Task_Services service;

	@RequestMapping("/project/{id}/task")
	List<Task> getProject(@PathVariable int id) {
		return service.getAllProjectTask(id);
	}

	@RequestMapping("/project/{id}/task/{id}")
	Optional<Task> getTask(@PathVariable("id") int id) {
		return service.getTask(id);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/project/{pid}/{eid}/task/")
	void addTask(@RequestBody Task task, @PathVariable int pid, @PathVariable int eid) {
		task.setProject(new Project(pid, "", "", "", "", "", ""));
		task.setEmp(new Employee(eid, "", 0, ""));
		service.addTask(task);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/project/{pid}/{eid}/task/{tId}")
	void updateTask(@RequestBody Task task, @PathVariable int tId, @PathVariable int pid, @PathVariable int eid) {

		task.setTaskId(tId);
		task.setProject(new Project(pid, "", "", "", "", "", ""));
		task.setEmp(new Employee(eid, "", 0, ""));
		service.updateTask(task);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/project/{pid}/task/{id}")
	void deleteTask(@PathVariable int id) {
		service.deleteTask(id);
	}
}
