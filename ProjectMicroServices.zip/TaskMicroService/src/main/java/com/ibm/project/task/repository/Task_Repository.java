package com.ibm.project.task.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.project.task.bean.Task;

@Repository
public interface Task_Repository extends CrudRepository<Task, Integer> {
	List<Task> findByProjectProjectId(int id);
}
