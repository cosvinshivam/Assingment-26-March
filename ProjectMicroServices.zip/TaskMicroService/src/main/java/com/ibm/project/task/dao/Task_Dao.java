package com.ibm.project.task.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibm.project.task.bean.Task;
import com.ibm.project.task.repository.Task_Repository;
@Repository
public class Task_Dao {

	   
		@Autowired
		Task_Repository repo;
		public List<Task> getAllProjectTask(int id) {
			return repo.findByProjectProjectId(id); 
		}

		public Optional<Task> getTask(int id) {
			return repo.findById(id);
		}

		public void deleteTask(int id) {
			repo.deleteById(id);
		}

		public void updateTask(Task task) {
		     repo.save(task);	
		}

		public void addTask(Task task) {
		    repo.save(task);
		}
}
