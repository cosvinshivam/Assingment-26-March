package com.ibm.project.admin.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibm.project.admin.bean.Admin;
import com.ibm.project.admin.repository.Admin_Repository;
@Repository
public class Admin_Dao {

	
	@Autowired
	Admin_Repository repo;

	public Iterable<Admin> getAdmin() {
		return repo.findAll();
	}
}
