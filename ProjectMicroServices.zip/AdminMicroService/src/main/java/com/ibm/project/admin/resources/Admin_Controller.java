package com.ibm.project.admin.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.project.admin.bean.Admin;
import com.ibm.project.admin.services.Admin_Services;

@RestController
public class Admin_Controller {
	@Autowired
	Admin_Services service;
	
	@RequestMapping(name="/admin")
	Iterable<Admin> getAdmin() {
		return service.getAdmin();
	}
}
