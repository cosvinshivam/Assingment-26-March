package com.ibm.project.employee.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.project.employee.bean.Employee;
import com.ibm.project.employee.dao.Employee_Dao;

@Service
public class Employee_Services {
	
	@Autowired
	Employee_Dao dao;

	public int getProjectEmployee(int id)
	{
		return dao.getProjectEmployee(id);
	}

	public List<Employee> getEmployee()
	{
		return dao.getEmployee();
	}
	
	public void deleteEmployee(int id) {
		dao.deleteEmployee(id);
	}

	public void updateEmployee(Employee emp) {
	     dao.updateEmployee(emp);	
	}

	public void addEmployee(Employee emp) {
	    dao.addEmployee(emp);
	}

}
