package com.ibm.project.employee.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ibm.project.employee.bean.Employee;

@Repository
public interface Employee_Repository extends CrudRepository<Employee,Integer> {
	@Query(value="select * from employee where project_project_id=?1", nativeQuery=true)
	public List<Employee> getAllByProjectId(Integer id);
	
	
	
}