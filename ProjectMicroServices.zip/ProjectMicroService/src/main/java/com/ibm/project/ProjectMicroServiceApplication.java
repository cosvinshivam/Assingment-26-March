package com.ibm.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectMicroServiceApplication.class, args);
	}

}
