		$('button').on('click', function () {
			 $a=this.id;
			console.log($a);
		$("#"+$a).load('enroll?id='+$a,function(responseValue, statusValue, xhr)
		{
			if(statusValue == 'success')
			{	
				 	//$("#"+$a).html(responseValue);
				console.log(responseValue);
			}      
			else
			console.log("SOmething wrong...");
		});
		
})

