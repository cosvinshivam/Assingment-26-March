package com.ibm.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Fetch_dao {
	Connection con;
	Statement stmt;
	int n;
	ResultSet rs;
	public Fetch_dao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ibm?useUnicode=true&u"
						+ "seJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
						"root","");
		      stmt= con.createStatement();
		} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
		}

	}
	
	public int fetch_ID(int i)
	{
		try {
			
		String sql="select * from Training where trainingId='"+i+"'";
		ResultSet rs=stmt.executeQuery(sql);
		
		if(rs.next())
		{
			n=rs.getInt(3);

		} 
		}
		catch (SQLException e) {
	         System.out.println(e);		
		}
		
		
		return n;
		
	}
	
	
	public boolean update(int i)
	{
		int flag=0;
		try {
	
		String sql1="update Training set AvailableSeats=AvailableSeats-1 where trainingId=?";
		PreparedStatement pst=con.prepareStatement(sql1);
		pst.setInt(1, i);
		int i1=pst.executeUpdate();
		if(i1>0)
		flag=1;
		}
		catch ( SQLException e) {
	         System.out.println(e);		
		}
		if(flag==1)
			return true;
		else
		    return false;
	}
	
	public ResultSet details()
	{
		
		
		try {
			String sql="select * from Training";
			 rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
     return rs;
	}
	
	
}
