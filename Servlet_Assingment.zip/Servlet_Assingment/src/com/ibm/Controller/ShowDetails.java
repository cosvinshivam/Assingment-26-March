package com.ibm.Controller;

import java.sql.ResultSet;

import com.ibm.Dao.Fetch_dao;

public class ShowDetails {

	public ResultSet fetch()
	{
		return new Fetch_dao().details();
	}
}
