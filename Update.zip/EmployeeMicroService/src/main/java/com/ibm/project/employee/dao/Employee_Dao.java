package com.ibm.project.employee.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibm.project.employee.bean.Employee;
import com.ibm.project.employee.repository.Employee_Repository;

@Repository
public class Employee_Dao {

	@Autowired
	Employee_Repository repo;

	public int getProjectEmployee(int id) {
		return id;
	}

	public List<Employee> getEmployee() {
		return (List<Employee>) repo.findAll();
	}

	public void deleteEmployee(int id) {

		repo.deleteById(id);
	}

	public void updateEmployee(Employee emp) {
		repo.save(emp);
	}

	public void addEmployee(Employee emp) {
		repo.save(emp);
	}

	public Optional<Employee> getEmployeeById(int id) {
		return repo.findById(id);
	}
}
