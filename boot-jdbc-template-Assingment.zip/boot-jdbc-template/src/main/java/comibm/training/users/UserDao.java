package comibm.training.users;

import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.ibm.training.bean.User;

@Repository
public class UserDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	public String getUser(int id) {
		String sql="select userName from test where userId=?";
		return jdbcTemplate.queryForObject(sql, new Object[]{id},String.class);	
	}
	public List<User> getUser() {
		String sql="select * from test";
		return jdbcTemplate.query(sql,new UserMapper());	
	}
	public void updateUser(int id) {
		String sql="update test set userName='Shivam Shukla' where userId=?";
		jdbcTemplate.update(sql, new Object[]{id});	
	}
	public void deleteUser(int id) {
		String sql="delete from test where userId=?";
		jdbcTemplate.update(sql, new Object[]{id});	
	}
	public void addUser(User user) {
		String sql="insert into test values(?,?,?)";
		jdbcTemplate.update(sql, new Object[]{user.getUserName(),user.getUserAddress(),user.getUserId()});	
	}
	public User getParticularUser(int id) {
		String sql="select * from test where userId=?";
		return jdbcTemplate.queryForObject(sql, new Object[]{id},new UserMapper());	
	}

}
class UserMapper implements RowMapper<User>{
   

	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		User u=new User();
		u.setUserName(rs.getString(1));
		u.setUserAddress(rs.getString(2));
		u.setUserId(rs.getInt(3));
		return u;
	}
	
}
