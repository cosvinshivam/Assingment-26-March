package comibm.training.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.training.bean.User;

@Service
public class USerService {

	@Autowired
	UserDao dao;
	String getUser(int id)
	{
		return dao.getUser(id);
	}
	
	public List<User> getUser() {

	return dao.getUser();
	}
	public void updateUser(int id) {
		dao.updateUser(id);
	}
	public void deleteUser(int id) {
		dao.deleteUser(id);
	}

	public void addUser(User user) {
	    dao.addUser(user);
	}

	public User getParticularUser(int id) {
		return dao.getParticularUser(id);
	}
}
