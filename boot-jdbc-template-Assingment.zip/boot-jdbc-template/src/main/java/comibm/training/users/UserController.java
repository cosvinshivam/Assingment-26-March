package comibm.training.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.training.bean.User;

@RestController
public class UserController {

	@Autowired
	USerService service;
//	@RequestMapping("/users/{id}")
//    String getUser(@PathVariable int id) {
//		return service.getUser(id);
//	}
	
	@RequestMapping("/users")
	public List<User> getUser() {
		return service.getUser();	
	}
	@RequestMapping(method = RequestMethod.PUT, value = "/users/{id}")
	public void updateUser(@PathVariable int id) {
		service.updateUser(id);
	}
	@RequestMapping(method = RequestMethod.DELETE, value = "/users/{id}")
	public void deleteUser(@PathVariable int id) {
		service.deleteUser(id);
	}
	@RequestMapping(method = RequestMethod.POST,value = "/users")
	void addUser() {
		service.addUser(new User("Krishna","Delhi",001));
    }
	
	@RequestMapping("/users/{id}")
	User getParticularUser(@PathVariable int id) {
		return service.getParticularUser(id);
    }
}
