package com.ibm.training.bean;

public class User {
String userName,userAddress;
int userId;
public User() {
	
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserAddress() {
	return userAddress;
}
public void setUserAddress(String userAddress) {
	this.userAddress = userAddress;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public User(String userName, String userAddress, int userId) {
	//super();
	this.userName = userName;
	this.userAddress = userAddress;
	this.userId = userId;
}
//public String toString()
//{
//	return "USERNAME:"+this.getUserName()+" USERADDRESS:"+this.getUserAddress()+" USERID:"+this.getUserId();
//}
}
